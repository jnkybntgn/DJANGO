from django.shortcuts import get_object_or_404, render
from django.views.generic import TemplateView
from .models import Product

# Create your tests here.

def prds_list(request):
  context = {
    "prds": Product.objects.all(),
  }
  return render(request, 'app_project/prds_list.html', context=context)

def prds_detail(request,id):
  context={
    "id": id,
    "product": get_object_or_404(Product, pk=id),
  }
  return render(request, 'app_project/prds_detail.html', context=context)

