from django.contrib import admin
from django.contrib.admin import DateFieldListFilter
from .models import Product


class ProductAdmin(admin.ModelAdmin):
  fields = ('product_name','stock','price','description','date_entry','photo')
  list_filter = (
    ('date_entry', DateFieldListFilter),
  )
  list_display = ('product_name','stock','price','date_entry')

admin.site.register(Product,ProductAdmin)

