from django.db import models
from django.utils import timezone

class Product(models.Model):
  
  product_name = models.CharField(max_length=200)
  stock = models.IntegerField(max_length=100)
  description = models.CharField(max_length=1000)
  price = models.FloatField(max_length=10)
  date_entry = models.DateTimeField(default=timezone.now())
  photo = models.ImageField(upload_to='image/')

  def __str__(self):
    return self.product_name
